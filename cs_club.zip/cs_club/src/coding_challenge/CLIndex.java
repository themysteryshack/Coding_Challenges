package coding_challenge;
import java.util.*;

public class CLIndex {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); //creating a Scanner object
		System.out.print("Text: "); //prompts the user to enter a text
		String text = input.nextLine() + " "; //scans and stores the input to string variable text
		//the following variables are declared as a float to divide big decimal numbers
		float letters = 0; 
		float sentences = 0;
		float words = 0;
		//the following for-loop iterates through each character of the string entered by the user
		//and identifies how many sentences, letters, and words exist in the given string by:
		//(1) adding up the number of letters in the string. The isLetter method is a built-in method that is
		//    invoked which requires a character as its parameter and determines whether or not the given character 
		//    is a letter. If it is a letter, a 1 is added to the letters variable.
		//(2) adding up the number of sentences in the string. The isSentence method is invoked which is a method located
		//    in the CLIndex class that requires a character as its parameter. If a punctuation is found, a 1 is added to the
		//    sentences variable.
		//(3) adding up the number of words in the string. Each character of the string is simply compared to a 
		//    space character ' '. If the character is a space, a 1 is added to the words variable.
		for (int i = 0; i<text.length(); i++) {
			if (Character.isLetter(text.charAt(i))) {
				letters++;
			}
			else if (isSentence(text.charAt(i))) {
				sentences++;
			}
			else if (text.charAt(i)== ' ') {
				words++;
			}
		}
		//the following calculate L, S, and the Coleman-Liau index
		//then prints the index
		float L = (letters/words) * 100;
		float S = (sentences/words) * 100;
		int index = (int) (0.0588*L - 0.296*S - 15.8);
		System.out.println("Output: " + "Grade " + index);
		input.close();
	}
	
	//The following method checks for punctuation, specifically a period, question mark, or an exclamation mark
	//it returns true if a punctuation is found
	//it returns false if not found
	public static boolean isSentence(char c) {
		char punk = c;
		if (punk == '!' || punk== '.' || punk == '?') {
			return true;
		}
		return false;
	}
	
}
//Text: 
//Output: Grade 3
